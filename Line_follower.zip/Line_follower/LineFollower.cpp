#include "LineFollower.h"

LineFollower::LineFollower(int ENA_pin, int ENB_pin, int ls_pin, int rs_pin, int m1_pin1, int m1_pin2, int m2_pin1, int m2_pin2) {
  _ENA = ENA_pin;
  _ENB = ENB_pin;
  _ls = ls_pin;
  _rs = rs_pin;
  _m1_pin1 = m1_pin1;
  _m1_pin2 = m1_pin2;
  _m2_pin1 = m2_pin1;
  _m2_pin2 = m2_pin2;
}

void LineFollower::setup() {
  pinMode(_ls, INPUT);
  pinMode(_rs, INPUT);
  pinMode(_m1_pin1, OUTPUT);
  pinMode(_m1_pin2, OUTPUT);
  pinMode(_m2_pin1, OUTPUT);
  pinMode(_m2_pin2, OUTPUT);
  pinMode(_ENA, OUTPUT);
  pinMode(_ENB, OUTPUT);
}

void LineFollower::followLine() {
  int ls = digitalRead(_ls);
  int rs = digitalRead(_rs);

  if (ls == HIGH && rs == HIGH) {
    digitalWrite(_m1_pin1, LOW);
    digitalWrite(_m1_pin2, LOW);
    digitalWrite(_m2_pin1, LOW);
    digitalWrite(_m2_pin2, LOW);
    analogWrite(_ENA, 200);
    analogWrite(_ENB, 200);
  }

  if (ls == LOW && rs == HIGH) {
    digitalWrite(_m1_pin1, HIGH);
    digitalWrite(_m1_pin2, LOW);
    digitalWrite(_m2_pin1, LOW);
    digitalWrite(_m2_pin2, LOW);
    analogWrite(_ENA, 200);
    analogWrite(_ENB, 200);
  }

  if (ls == HIGH && rs == LOW) {
    digitalWrite(_m1_pin1, LOW);
    digitalWrite(_m1_pin2, LOW);
    digitalWrite(_m2_pin1, HIGH);
    digitalWrite(_m2_pin2, LOW);
    analogWrite(_ENA, 200);
    analogWrite(_ENB, 200);
  }

  if (ls == LOW && rs == LOW) {
    digitalWrite(_m1_pin1, HIGH);
    digitalWrite(_m1_pin2, LOW);
    digitalWrite(_m2_pin1, HIGH);
    digitalWrite(_m2_pin2, LOW);
    analogWrite(_ENA, 200);
    analogWrite(_ENB, 200);
  }
}
