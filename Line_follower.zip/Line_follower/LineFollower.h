#ifndef LineFollower_h
#define LineFollower_h

#include "Arduino.h"

class LineFollower {
  public:
    LineFollower(int ENA_pin, int ENB_pin, int ls_pin, int rs_pin, int m1_pin1, int m1_pin2, int m2_pin1, int m2_pin2);
    void setup();
    void followLine();
    
  private:
    int _ENA;
    int _ENB;
    int _ls;
    int _rs;
    int _m1_pin1;
    int _m1_pin2;
    int _m2_pin1;
    int _m2_pin2;
};

#endif
